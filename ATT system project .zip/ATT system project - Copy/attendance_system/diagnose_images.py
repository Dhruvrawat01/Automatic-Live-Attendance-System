from PIL import Image
import numpy as np
import os

folder = 'known_faces'
for f in os.listdir(folder):
    path = os.path.join(folder, f)
    img = Image.open(path)
    print(f"{f}: mode={img.mode}, size={img.size}")
    rgb = img.convert("RGB")
    arr = np.array(rgb)
    print(f"  numpy dtype={arr.dtype}, shape={arr.shape}")
