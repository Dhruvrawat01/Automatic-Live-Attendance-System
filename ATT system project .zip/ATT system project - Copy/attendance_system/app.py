# app.py
# Enhanced Streamlit UI Dashboard
# Improvements:
#   1. Start/Stop webcam recognition from the UI (no need for Terminal 1)
#   2. Admin Settings page — configure attendance mode & cooldown
#   3. Webcam status indicator in sidebar
#   4. Updated instructions panel

import streamlit as st
import pandas as pd
import os
import json
import subprocess
import sys
from datetime import datetime
from PIL import Image

# ── CONFIG ───────────────────────────────────────────────────────────────────
BASE_DIR        = os.path.dirname(os.path.abspath(__file__))
LOGS_DIR        = os.path.join(BASE_DIR, "attendance_logs")
KNOWN_FACES_DIR = os.path.join(BASE_DIR, "known_faces")
ENCODE_SCRIPT   = os.path.join(BASE_DIR, "encode_faces.py")
ATTENDANCE_SCRIPT = os.path.join(BASE_DIR, "attendance.py")
CONFIG_FILE     = os.path.join(BASE_DIR, "config.json")

os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(KNOWN_FACES_DIR, exist_ok=True)

DEFAULT_CONFIG = {
    "attendance_mode": "once_per_day",
    "cooldown_minutes": 60,
    "threshold": 0.45,
    "low_conf_upper": 0.6
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            cfg = json.load(f)
        for k, v in DEFAULT_CONFIG.items():
            cfg.setdefault(k, v)
        return cfg
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=4)
# ─────────────────────────────────────────────────────────────────────────────


# ── PAGE CONFIG ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AI Attendance System",
    page_icon="",
    layout="wide"
)
# ─────────────────────────────────────────────────────────────────────────────


# ── SESSION STATE — Webcam process handle ─────────────────────────────────────
if "webcam_proc" not in st.session_state:
    st.session_state["webcam_proc"] = None
# ─────────────────────────────────────────────────────────────────────────────


# ── WEBCAM PROCESS HELPERS ────────────────────────────────────────────────────
# Use the venv's Python explicitly — sys.executable may point to global Python
VENV_PYTHON = os.path.join(BASE_DIR, "attendance_env", "Scripts", "python.exe")

# Fallback: if venv python doesn't exist, use sys.executable
if not os.path.exists(VENV_PYTHON):
    VENV_PYTHON = sys.executable

def is_webcam_running():
    proc = st.session_state["webcam_proc"]
    return proc is not None and proc.poll() is None

def start_webcam():
    if not is_webcam_running():
        try:
            proc = subprocess.Popen(
                [VENV_PYTHON, ATTENDANCE_SCRIPT],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=BASE_DIR
            )
            # Wait briefly to catch immediate crashes (missing imports, etc.)
            import time
            time.sleep(1.5)
            
            if proc.poll() is not None:
                # Process died immediately — read the error
                _, stderr = proc.communicate()
                error_msg = stderr.decode("utf-8", errors="replace") if stderr else "Unknown error"
                st.session_state["webcam_proc"] = None
                st.session_state["webcam_error"] = error_msg
            else:
                st.session_state["webcam_proc"] = proc
                st.session_state["webcam_error"] = None
        except Exception as e:
            st.session_state["webcam_error"] = str(e)

def stop_webcam():
    proc = st.session_state["webcam_proc"]
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
    st.session_state["webcam_proc"] = None

# Initialize error state
if "webcam_error" not in st.session_state:
    st.session_state["webcam_error"] = None
# ─────────────────────────────────────────────────────────────────────────────


# ── SIDEBAR ───────────────────────────────────────────────────────────────────
st.sidebar.title("AI Attendance System")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigation",
    ["Live Attendance", "Attendance Logs", "Register Student", "Admin Settings"]
)

st.sidebar.markdown("---")

# Webcam Status indicator
if is_webcam_running():
    st.sidebar.success("Webcam: **Running**")
else:
    st.sidebar.error("Webcam: **Stopped**")

# Start / Stop buttons in sidebar
col_a, col_b = st.sidebar.columns(2)
with col_a:
    if st.button("Start", use_container_width=True, disabled=is_webcam_running()):
        start_webcam()
        st.rerun()
with col_b:
    if st.button("Stop", use_container_width=True, disabled=not is_webcam_running()):
        stop_webcam()
        st.rerun()

st.sidebar.caption("Starts `attendance.py` automatically — no separate terminal needed.")
# ─────────────────────────────────────────────────────────────────────────────


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 1 — LIVE ATTENDANCE
# ═══════════════════════════════════════════════════════════════════════════════
if page == "Live Attendance":

    st.title("Live Attendance")

    today        = datetime.now()
    today_str    = today.strftime("%Y-%m-%d")
    display_date = today.strftime("%A, %d %B %Y")
    st.markdown(f"### {display_date}")
    st.markdown("---")

    # Webcam controls inline (mirrors sidebar for convenience)
    ctrl_col1, ctrl_col2, ctrl_col3 = st.columns([1, 1, 4])
    with ctrl_col1:
        if st.button("Start Webcam", use_container_width=True, disabled=is_webcam_running()):
            start_webcam()
            st.rerun()
    with ctrl_col2:
        if st.button("Stop Webcam", use_container_width=True, disabled=not is_webcam_running()):
            stop_webcam()
            st.rerun()
    with ctrl_col3:
        if is_webcam_running():
            st.success("Recognition engine is running — students are being detected.")
        else:
            st.warning("Recognition engine is stopped. Press **Start Webcam** to begin.")

    # Show error if webcam failed to start
    if st.session_state.get("webcam_error"):
        st.error("Webcam failed to start. See error details below:")
        with st.expander("Error Details", expanded=True):
            st.code(st.session_state["webcam_error"])
        st.info(f"**Python being used:** `{VENV_PYTHON}`")

    with st.expander("How to use — click to expand", expanded=False):
        st.markdown("""
        **You no longer need a separate terminal!**
        - Press **Start Webcam** above — the recognition engine starts automatically.
        - A webcam window will open on your desktop showing live detections.
        - Press **Stop Webcam** to stop it, or press **Q** inside the webcam window.
        - Click **Refresh** below to update the attendance table.
        - Enable **auto-refresh** to have the table update every 10 seconds automatically.
        """)

    st.markdown("---")

    today_csv = os.path.join(LOGS_DIR, f"{today_str}.csv")
    col1, col2 = st.columns([3, 1])

    with col2:
        if st.button("Refresh", use_container_width=True):
            st.rerun()

    if os.path.exists(today_csv):
        df = pd.read_csv(today_csv)
        total_marked = len(df)

        st.success(f"**{total_marked} student(s) marked today**")

        with col1:
            st.markdown(f"**Showing attendance for:** `{today_str}`")

        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Name": st.column_config.TextColumn("Name", width="medium"),
                "Date": st.column_config.TextColumn("Date", width="medium"),
                "Time": st.column_config.TextColumn("Time", width="medium"),
            }
        )
        st.caption("Click Refresh to load new entries logged by the webcam system.")
    else:
        st.info("No attendance logged yet for today. Start the webcam engine above.")

    st.markdown("---")
    auto_refresh = st.toggle("Enable auto-refresh every 10 seconds", value=False)
    if auto_refresh:
        import time
        time.sleep(10)
        st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 2 — ATTENDANCE LOGS
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "Attendance Logs":

    st.title("Attendance Logs")
    st.markdown("---")

    log_files = sorted(
        [f for f in os.listdir(LOGS_DIR) if f.endswith(".csv")],
        reverse=True
    )

    if not log_files:
        st.info("No attendance logs found yet. Run the attendance system first.")
    else:
        date_options  = [f.replace(".csv", "") for f in log_files]
        selected_date = st.selectbox("Select a date to view", options=date_options, index=0)
        selected_csv  = os.path.join(LOGS_DIR, f"{selected_date}.csv")

        if os.path.exists(selected_csv):
            df = pd.read_csv(selected_csv)
            st.markdown(f"### Attendance for `{selected_date}`")

            col1, col2 = st.columns([2, 1])
            with col1:
                st.success(f"**{len(df)} student(s) marked on this date**")
            with col2:
                csv_data = df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    label="⬇️ Download CSV",
                    data=csv_data,
                    file_name=f"attendance_{selected_date}.csv",
                    mime="text/csv",
                    use_container_width=True
                )

            st.dataframe(
                df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Name": st.column_config.TextColumn("Name", width="medium"),
                    "Date": st.column_config.TextColumn("Date", width="medium"),
                    "Time": st.column_config.TextColumn("Time", width="medium"),
                }
            )
        else:
            st.error("Selected log file not found.")


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 3 — REGISTER NEW STUDENT
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "Register Student":

    st.title("Register New Student")
    st.markdown("---")

    st.markdown("""
    Upload a clear, front-facing photo of the student.
    After submission, the system will automatically re-encode all faces
    so the new student is recognized immediately in the webcam system.
    """)
    st.markdown("---")

    student_name   = st.text_input("Student Name", placeholder="Enter full name (e.g. Shoukath)", max_chars=50)
    uploaded_photo = st.file_uploader("Upload Student Photo", type=["jpg", "jpeg", "png"],
                                      help="One face per photo. Clear, front-facing, good lighting.")

    if uploaded_photo is not None:
        preview_img = Image.open(uploaded_photo)
        col1, col2  = st.columns([1, 2])
        with col1:
            st.image(preview_img, caption="Preview", width=200)
        with col2:
            st.markdown("**Photo requirements:**")
            st.markdown("- One face only in the frame")
            st.markdown("- Face clearly visible and front-facing")
            st.markdown("- Good lighting, not blurry")
            st.markdown("- Minimum face size: 80×80 pixels")

    st.markdown("---")
    submit = st.button("Register Student", use_container_width=True, type="primary")

    if submit:
        if not student_name.strip():
            st.error("Please enter a student name.")
        elif uploaded_photo is None:
            st.error("Please upload a photo.")
        else:
            clean_name = student_name.strip().replace(" ", "_")
            save_path  = os.path.join(KNOWN_FACES_DIR, f"{clean_name}.jpg")

            try:
                img = Image.open(uploaded_photo).convert("RGB")
                img.save(save_path, "JPEG")
                st.info(f"Photo saved as `{clean_name}.jpg` in known_faces/")
            except Exception as e:
                st.error(f"Failed to save photo: {e}")
                st.stop()

            with st.spinner("Re-encoding all faces... please wait."):
                try:
                    result = subprocess.run(
                        [VENV_PYTHON, ENCODE_SCRIPT],
                        capture_output=True, text=True, timeout=60
                    )
                    if result.returncode == 0:
                        st.success(f"**{clean_name}** registered successfully!")
                        st.markdown("The student will now be recognized by the webcam system.")
                        st.code(result.stdout, language="text")
                    else:
                        st.error("Encoding failed. See details below.")
                        st.code(result.stderr, language="text")
                except subprocess.TimeoutExpired:
                    st.error("Encoding took too long. Check your known_faces/ folder and try again.")
                except Exception as e:
                    st.error(f"Unexpected error during encoding: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# PAGE 4 — ADMIN SETTINGS
# ═══════════════════════════════════════════════════════════════════════════════
elif page == "Admin Settings":

    st.title("Admin Settings")
    st.markdown("---")

    cfg = load_config()

    st.markdown("### Attendance Mode")
    st.markdown("""
    Choose how the system decides whether to mark a student:
    - **Once per day** — each student is marked only once per calendar day, regardless of how many times they appear.
    - **Cooldown** — a student can be marked again after a set number of minutes (useful for multi-session classes or labs).
    """)

    mode = st.radio(
        "Attendance Mode",
        options=["once_per_day", "cooldown"],
        index=0 if cfg["attendance_mode"] == "once_per_day" else 1,
        format_func=lambda x: "Once per day" if x == "once_per_day" else "Cooldown (re-entry allowed)",
        horizontal=True
    )

    cooldown_mins = cfg["cooldown_minutes"]
    if mode == "cooldown":
        cooldown_mins = st.slider(
            "Cooldown duration (minutes)",
            min_value=5,
            max_value=480,
            value=cfg["cooldown_minutes"],
            step=5,
            help="Student can be marked again after this many minutes."
        )
        st.info(f"A student will be allowed to mark attendance again after **{cooldown_mins} minutes**.")

    st.markdown("---")
    st.markdown("### Recognition Sensitivity")

    threshold = st.slider(
        "Face Match Threshold",
        min_value=0.30,
        max_value=0.70,
        value=cfg["threshold"],
        step=0.01,
        help="Lower = stricter (fewer false positives). Higher = more lenient (fewer missed detections). Default: 0.45"
    )

    low_conf = st.slider(
        "Low Confidence Upper Limit",
        min_value=threshold + 0.01,
        max_value=0.90,
        value=max(cfg["low_conf_upper"], threshold + 0.01),
        step=0.01,
        help="Faces between Threshold and this value show as 'Low Confidence'. Default: 0.60"
    )

    col1, col2, col3 = st.columns([1, 1, 4])

    st.markdown("---")

    # Current config preview
    with st.expander("Current config.json preview"):
        st.json(cfg)

    save_col, _ = st.columns([1, 3])
    with save_col:
        if st.button("Save Settings", use_container_width=True, type="primary"):
            new_cfg = {
                "attendance_mode":  mode,
                "cooldown_minutes": cooldown_mins,
                "threshold":        round(threshold, 2),
                "low_conf_upper":   round(low_conf, 2)
            }
            save_config(new_cfg)
            st.success("Settings saved to `config.json`!")
            st.info("Restart the webcam engine (Stop → Start) for changes to take effect.")
            st.json(new_cfg)

    st.markdown("---")
    st.markdown("### Data Management")

    # ── Clear today's marked students ─────────────────────────────────────
    today_str  = datetime.now().strftime("%Y-%m-%d")
    today_csv  = os.path.join(LOGS_DIR, f"{today_str}.csv")
    has_today  = os.path.exists(today_csv)

    if has_today:
        try:
            df_today = pd.read_csv(today_csv)
            st.info(f"Today's log (`{today_str}.csv`) has **{len(df_today)} entries**.")
        except Exception:
            st.info(f"Today's log exists: `{today_str}.csv`")
    else:
        st.info("No attendance log for today yet.")

    clear_col, delete_col, _ = st.columns([1, 1, 2])

    with clear_col:
        if st.button("Clear Today's Log", use_container_width=True, disabled=not has_today):
            try:
                os.remove(today_csv)
                st.success(f"Cleared today's attendance log (`{today_str}.csv`).")
                # Auto-restart webcam so in-memory marked_today set is also reset
                if is_webcam_running():
                    stop_webcam()
                    start_webcam()
                    st.info("Webcam restarted to reset in-memory tracking.")
                else:
                    st.info("Start the webcam again — all students can now be re-marked.")
                st.rerun()
            except Exception as e:
                st.error(f"Failed to clear: {e}")

    # ── Delete ALL logs ───────────────────────────────────────────────────
    all_logs = [f for f in os.listdir(LOGS_DIR) if f.endswith(".csv")]

    with delete_col:
        if st.button("Delete ALL Logs", use_container_width=True, disabled=len(all_logs) == 0):
            st.session_state["confirm_delete_all"] = True

    if st.session_state.get("confirm_delete_all"):
        st.warning(f"This will permanently delete **{len(all_logs)} log file(s)**. This cannot be undone.")
        confirm_col1, confirm_col2, _ = st.columns([1, 1, 2])
        with confirm_col1:
            if st.button("Yes, delete all", use_container_width=True):
                deleted = 0
                for f in all_logs:
                    try:
                        os.remove(os.path.join(LOGS_DIR, f))
                        deleted += 1
                    except Exception:
                        pass
                st.success(f"Deleted {deleted} log file(s).")
                st.session_state["confirm_delete_all"] = False
                if is_webcam_running():
                    stop_webcam()
                    start_webcam()
                    st.info("Webcam restarted.")
                st.rerun()
        with confirm_col2:
            if st.button("Cancel", use_container_width=True):
                st.session_state["confirm_delete_all"] = False
                st.rerun()