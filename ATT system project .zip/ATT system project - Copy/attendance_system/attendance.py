# attendance.py
# Enhanced Recognition Engine
# Improvements:
#   1. Pre-loads today's CSV so restarts don't re-mark students
#   2. Admin config via config.json (once_per_day or cooldown mode)
#   3. Beep sound on successful marking (cross-platform)
#   4. 2-second green flash confirmation overlay on webcam frame
#   5. Cooldown-aware marking logic

import pandas as pd
import threading
import json
import sys
from datetime import datetime, timedelta
import face_recognition
import cv2
import pickle
import os

# ── CONFIG ───────────────────────────────────────────────────────────────────
BASE_DIR       = os.path.dirname(os.path.abspath(__file__))
ENCODINGS_FILE = os.path.join(BASE_DIR, "encodings", "encodings.pkl")
CONFIG_FILE    = os.path.join(BASE_DIR, "config.json")
LOGS_DIR       = os.path.join(BASE_DIR, "attendance_logs")
os.makedirs(LOGS_DIR, exist_ok=True)
# ─────────────────────────────────────────────────────────────────────────────


# ── LOAD ADMIN CONFIG ─────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "attendance_mode": "once_per_day",   # "once_per_day" or "cooldown"
    "cooldown_minutes": 60,              # used only in "cooldown" mode
    "threshold": 0.5,
    "low_conf_upper": 0.6
}

if os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, "r") as f:
        config = json.load(f)
    # Fill in any missing keys with defaults
    for k, v in DEFAULT_CONFIG.items():
        config.setdefault(k, v)
    print(f"[INFO] Config loaded: mode={config['attendance_mode']}, "
          f"cooldown={config['cooldown_minutes']}min, "
          f"threshold={config['threshold']}")
else:
    config = DEFAULT_CONFIG
    # Write default config so admin can edit it
    with open(CONFIG_FILE, "w") as f:
        json.dump(DEFAULT_CONFIG, f, indent=4)
    print(f"[INFO] config.json not found — created with defaults.")

THRESHOLD      = config["threshold"]
LOW_CONF_UPPER = config["low_conf_upper"]
MODE           = config["attendance_mode"]         # "once_per_day" or "cooldown"
COOLDOWN_MINS  = config["cooldown_minutes"]
# ─────────────────────────────────────────────────────────────────────────────


# ── LOAD ENCODINGS ────────────────────────────────────────────────────────────
if not os.path.exists(ENCODINGS_FILE):
    print("[ERROR] encodings.pkl not found. Run encode_faces.py first.")
    exit()

with open(ENCODINGS_FILE, "rb") as f:
    data = pickle.load(f)

known_encodings = data["encodings"]
known_names     = data["names"]
print(f"[INFO] Loaded {len(known_names)} known face(s): {known_names}")
# ─────────────────────────────────────────────────────────────────────────────


# ── ATTENDANCE STATE ──────────────────────────────────────────────────────────
# marked_today   → set of names already marked (for once_per_day mode)
# last_marked_at → dict of name → datetime (for cooldown mode)
marked_today   = set()
last_marked_at = {}   # name → datetime of last marking
write_lock     = threading.Lock()


# ── PRE-LOAD TODAY'S EXISTING ENTRIES ─────────────────────────────────────────
# Prevents re-marking after a script restart mid-day
today_csv = os.path.join(LOGS_DIR, datetime.now().strftime("%Y-%m-%d") + ".csv")
if os.path.exists(today_csv):
    try:
        df_existing = pd.read_csv(today_csv)
        for _, row in df_existing.iterrows():
            name = row["Name"]
            marked_today.add(name)
            # Parse last-seen time for cooldown tracking
            try:
                dt = datetime.strptime(f"{row['Date']} {row['Time']}", "%Y-%m-%d %H:%M:%S")
                last_marked_at[name] = dt
            except Exception:
                last_marked_at[name] = datetime.now()
        print(f"[INFO] Pre-loaded {len(marked_today)} already-marked student(s): {list(marked_today)}")
    except Exception as e:
        print(f"[WARNING] Could not pre-load today's CSV: {e}")
else:
    print("[INFO] No existing log for today — starting fresh.")
# ─────────────────────────────────────────────────────────────────────────────


# ── BEEP SOUND ────────────────────────────────────────────────────────────────
def beep():
    """Cross-platform beep on successful attendance marking."""
    try:
        if sys.platform == "win32":
            import winsound
            winsound.Beep(1000, 350)          # 1000 Hz for 350ms
        elif sys.platform == "darwin":
            os.system("afplay /System/Library/Sounds/Glass.aiff &")
        else:
            # Linux — terminal bell (works in most terminals)
            print("\a", end="", flush=True)
            # Also try paplay if available (silent fallback if not)
            os.system("paplay /usr/share/sounds/freedesktop/stereo/complete.oga 2>/dev/null &")
    except Exception:
        pass  # Never crash the main loop over a beep
# ─────────────────────────────────────────────────────────────────────────────


# ── SHOULD MARK CHECK ─────────────────────────────────────────────────────────
def should_mark(name):
    """
    Returns True if this student should be marked now.
    Respects the admin-configured mode (once_per_day / cooldown).
    """
    if MODE == "once_per_day":
        return name not in marked_today

    elif MODE == "cooldown":
        if name not in last_marked_at:
            return True
        elapsed = datetime.now() - last_marked_at[name]
        return elapsed >= timedelta(minutes=COOLDOWN_MINS)

    return True  # Unknown mode — default to allow
# ─────────────────────────────────────────────────────────────────────────────


# ── LOG ATTENDANCE ────────────────────────────────────────────────────────────
def log_attendance(name):
    """Write a single attendance entry to today's CSV. Thread-safe."""
    now      = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")
    csv_path = os.path.join(LOGS_DIR, f"{date_str}.csv")

    with write_lock:
        if not os.path.exists(csv_path):
            with open(csv_path, "w") as f:
                f.write("Name,Date,Time\n")
        with open(csv_path, "a") as f:
            f.write(f"{name},{date_str},{time_str}\n")

    # Update in-memory state
    marked_today.add(name)
    last_marked_at[name] = now

    print(f"[LOG] Marked: {name} at {time_str}")
    beep()
# ─────────────────────────────────────────────────────────────────────────────


# ── OPEN WEBCAM ───────────────────────────────────────────────────────────────
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("[INFO] Camera index 0 failed. Trying index 1...")
    cap = cv2.VideoCapture(1)
if not cap.isOpened():
    print("[ERROR] No webcam found. Check your camera connection.")
    exit()

print("[INFO] Webcam opened successfully. Press Q to quit.")
# ─────────────────────────────────────────────────────────────────────────────


# ── COLOR CONSTANTS (BGR) ─────────────────────────────────────────────────────
COLOR_GREEN  = (0, 200, 0)
COLOR_RED    = (0, 0, 220)
COLOR_ORANGE = (0, 140, 255)
COLOR_YELLOW = (0, 220, 220)
COLOR_FLASH  = (0, 255, 120)   # Bright green for confirmation flash
# ─────────────────────────────────────────────────────────────────────────────


# ── FLASH STATE ───────────────────────────────────────────────────────────────
# Tracks which students should show a "just marked" confirmation overlay
# name → datetime when the flash expires (2 seconds after marking)
flash_until = {}
FLASH_DURATION = timedelta(seconds=2)
# ─────────────────────────────────────────────────────────────────────────────


# ── CONFIRMATION BUFFER ───────────────────────────────────────────────────────
# Require N consecutive frames matching the SAME person before logging attendance.
# This prevents single-frame false positives from flickering matches.
CONFIRM_FRAMES_NEEDED = 2       # Must match same person 2 frames in a row
MIN_GAP_RATIO         = 0.08    # Best match must be 8% better than second-best
SCALE_FACTOR          = 0.7     # Process at 70% resolution (good accuracy, acceptable speed)
SCALE_INV             = 1.0 / SCALE_FACTOR  # ≈ 1.43 — used to scale box coords back up

# Track per-face confirmation: name → consecutive frame count
confirm_counter = {}  # name → int (how many frames in a row this name matched)
last_seen_name  = {}  # face_position_key → last matched name (for tracking consistency)
# ─────────────────────────────────────────────────────────────────────────────


# ── MAIN LOOP ─────────────────────────────────────────────────────────────────
frame_count = 0

while True:
    ret, frame = cap.read()
    if not ret:
        print("[ERROR] Failed to read frame from webcam.")
        break

    frame_count += 1

    # ── Process at half resolution for better accuracy ─────────────────────
    small_frame = cv2.resize(frame, (0, 0), fx=SCALE_FACTOR, fy=SCALE_FACTOR)
    rgb_small   = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    face_locations = face_recognition.face_locations(rgb_small)
    face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

    now = datetime.now()

    # Track which names we see this frame (to decay counters for disappeared faces)
    names_this_frame = set()

    for face_encoding, (top, right, bottom, left) in zip(face_encodings, face_locations):

        # Scale coordinates back to full resolution
        top    = int(top    * SCALE_INV)
        right  = int(right  * SCALE_INV)
        bottom = int(bottom * SCALE_INV)
        left   = int(left   * SCALE_INV)

        distances = face_recognition.face_distance(known_encodings, face_encoding)

        label = "Unknown"
        if len(distances) > 0:
            label = f"Unknown (dist: {distances.min():.2f})"
        color = COLOR_RED
        name  = None

        if len(distances) > 0:
            sorted_indices = distances.argsort()
            best_index    = sorted_indices[0]
            best_distance = distances[best_index]

            # ── GAP CHECK: best must be clearly better than second-best ───
            is_clear_match = True
            if len(sorted_indices) > 1:
                second_distance = distances[sorted_indices[1]]
                gap = second_distance - best_distance
                if gap < (best_distance * MIN_GAP_RATIO):
                    # Too close — ambiguous match, treat as low confidence
                    is_clear_match = False

            if best_distance <= THRESHOLD and is_clear_match:
                name  = known_names[best_index]
                label = name
                color = COLOR_GREEN
                names_this_frame.add(name)

                # ── CONFIRMATION BUFFER LOGIC ─────────────────────────────
                confirm_counter[name] = confirm_counter.get(name, 0) + 1

                if confirm_counter[name] >= CONFIRM_FRAMES_NEEDED:
                    # Confirmed — log if not already marked
                    if should_mark(name):
                        log_attendance(name)
                        flash_until[name] = now + FLASH_DURATION
                    # Show confirmed label
                    label = f"{name} (Confirmed) [d:{best_distance:.2f}]"
                else:
                    # Still building confidence — show progress
                    label = f"{name} ({confirm_counter[name]}/{CONFIRM_FRAMES_NEEDED}) [d:{best_distance:.2f}]"
                    color = (0, 180, 0)  # Slightly dimmer green

            elif best_distance <= THRESHOLD and not is_clear_match:
                # Match distance is ok but too close to second-best
                label = f"Ambiguous Match [d:{best_distance:.2f}]"
                color = COLOR_ORANGE

            elif best_distance <= LOW_CONF_UPPER:
                label = f"Low Confidence [d:{best_distance:.2f}]"
                color = COLOR_ORANGE

        # ── FLASH CONFIRMATION OVERLAY ────────────────────────────────────
        if name and name in flash_until and now < flash_until[name]:
            cv2.rectangle(frame, (left - 4, top - 4), (right + 4, bottom + 4), COLOR_FLASH, 4)
            banner_y = max(top - 40, 10)
            cv2.rectangle(frame, (left - 4, banner_y - 28), (right + 4, banner_y + 4), COLOR_FLASH, cv2.FILLED)
            cv2.putText(frame, "ATTENDANCE MARKED!", (left, banner_y - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 0), 2)

        # ── ALREADY MARKED (non-flash) → yellow label ────────────────────
        elif name and name in marked_today and (name not in flash_until or now >= flash_until[name]):
            color = COLOR_YELLOW
            label = f"{name} - Already Marked"

        # ── Cooldown mode: show remaining wait time ───────────────────────
        if MODE == "cooldown" and name and name in last_marked_at:
            elapsed  = now - last_marked_at[name]
            remaining = timedelta(minutes=COOLDOWN_MINS) - elapsed
            if remaining.total_seconds() > 0:
                mins = int(remaining.total_seconds() // 60)
                secs = int(remaining.total_seconds() % 60)
                label = f"{name} (next in {mins}m {secs}s)"
                color = COLOR_YELLOW

        # ── Draw bounding box ─────────────────────────────────────────────
        cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
        cv2.rectangle(frame, (left, bottom), (right, bottom + 30), color, cv2.FILLED)
        cv2.putText(frame, label, (left + 5, bottom + 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.60, (255, 255, 255), 2)

    # ── Decay confirmation counters for names NOT seen this frame ─────────
    # Aggressive reset: if a name disappears for even 1 frame, reset to 0.
    # This kills flickering wrong matches instantly while correct matches
    # build up fast because they appear every frame.
    for tracked_name in list(confirm_counter.keys()):
        if tracked_name not in names_this_frame:
            del confirm_counter[tracked_name]

    # ── Top-left overlay ──────────────────────────────────────────────────
    current_time = now.strftime("%H:%M:%S")
    mode_label   = "Daily" if MODE == "once_per_day" else f"Cooldown {COOLDOWN_MINS}m"
    overlay_text = f"Time: {current_time}   |   Marked: {len(marked_today)}   |   Mode: {mode_label}"
    overlay_w    = min(len(overlay_text) * 11, frame.shape[1])
    cv2.rectangle(frame, (0, 0), (overlay_w, 35), (30, 30, 30), cv2.FILLED)
    cv2.putText(frame, overlay_text, (8, 24),
                cv2.FONT_HERSHEY_SIMPLEX, 0.60, (255, 255, 255), 2)

    # ── No face detected ──────────────────────────────────────────────────
    if not face_locations:
        cv2.putText(frame, "No face detected", (8, 65),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 255), 2)

    cv2.imshow("Attendance System", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print("[INFO] System closed cleanly.")