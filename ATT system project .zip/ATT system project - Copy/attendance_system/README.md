# 🎓 AI Attendance System

An AI-powered, real-time facial recognition attendance system built with Python, OpenCV, and Streamlit. This is a local desktop application designed to use your computer's webcam to automatically log attendance into CSV files.

## 🚀 Features
- **Real-Time Recognition:** Uses the webcam to detect and identify faces instantly.
- **Admin Dashboard:** A beautiful Streamlit interface to manage everything.
- **Smart Cooldowns:** Choose between "Once Per Day" or custom cooldown minutes.
- **Auto-Logging:** Saves daily attendance automatically to CSV files.
- **One-Click Registration:** Upload a photo in the UI, and the system automatically learns the new face.

---

## 🛠️ Installation & Setup (For First-Time Users)

Because this uses advanced AI libraries (`dlib` and `face_recognition`), you need to set up a Python environment first.

### 1. Prerequisites
- **Python 3.10** (Highly recommended. Python 3.12+ may struggle to build `dlib`).
- A working webcam.

### 2. Set up the Environment
Open your terminal in this folder and run these commands:

```bash
# Create a virtual environment
python -m venv attendance_env

# Activate the environment (Windows)
attendance_env\Scripts\activate

# Activate the environment (Mac/Linux)
source attendance_env/bin/activate
```

### 3. Install Dependencies
Because `dlib` is notoriously difficult to install on Windows (requires C++ compilers), a pre-built file is provided in the `setup_files` folder. 

With your environment activated, run these commands in order:

```bash
# 1. Install the pre-built dlib wheel FIRST
pip install setup_files\dlib-19.22.99-cp310-cp310-win_amd64.whl

# 2. Install numpy specifically
pip install numpy==1.26.4

# 3. Install the rest of the libraries
pip install -r requirements.txt
```

---

## 🖥️ How to Run the App

You only need to run ONE command to start the entire system. Open your terminal, ensure your virtual environment is activated, and run:

```bash
streamlit run app.py
```

This will automatically open the Admin Dashboard in your web browser. 

From the dashboard, you can:
1. Click **Start Webcam** to launch the recognition engine.
2. Register new students by uploading a photo.
3. View and download CSV attendance logs.
4. Tweak accuracy thresholds and cooldown timers in the Admin Settings.

---

## 📁 Folder Structure

- `app.py` — The Streamlit dashboard UI.
- `attendance.py` — The background engine that processes the webcam feed.
- `encode_faces.py` — The script that converts photos into AI facial math.
- `known_faces/` — Put your `.jpg` photos here (or upload via UI).
- `encodings/` — Stores the `encodings.pkl` database.
- `attendance_logs/` — Where the CSV daily logs are saved.
- `config.json` — Admin settings (auto-generated).
