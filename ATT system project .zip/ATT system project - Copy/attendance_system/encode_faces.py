# encode_faces.py
# Phase 2 — Face Registration & Encoding Pipeline
#
# PURPOSE: Reads all student photos from known_faces/, generates a 128-dimension
# face encoding vector for each, and saves everything to encodings/encodings.pkl.
# Run this script once after adding photos. Re-run any time a new student is added.

import face_recognition
import os
import pickle
import numpy as np
from PIL import Image, UnidentifiedImageError

# ── CONFIG ───────────────────────────────────────────────────────────────────
BASE_DIR          = os.path.dirname(os.path.abspath(__file__))
KNOWN_FACES_DIR   = os.path.join(BASE_DIR, "known_faces")
ENCODINGS_DIR     = os.path.join(BASE_DIR, "encodings")
ENCODINGS_FILE    = os.path.join(ENCODINGS_DIR, "encodings.pkl")
VALID_EXTENSIONS  = {".jpg", ".jpeg", ".png"}
MIN_FACE_HEIGHT   = 80   # pixels — faces smaller than this generate weak encodings
MIN_FACE_WIDTH    = 80
# ─────────────────────────────────────────────────────────────────────────────


def is_valid_encoding(encoding):
    """
    Check if the generated encoding is usable.
    An all-zero or near-zero vector means the encoding failed silently.
    """
    return np.linalg.norm(encoding) > 0.1


def encode_faces():
    """
    Loop through all images in known_faces/, encode each face,
    and save the results as a pickle file.
    """

    # Ensure required folders exist
    os.makedirs(ENCODINGS_DIR, exist_ok=True)

    # Check if known_faces folder itself exists
    if not os.path.exists(KNOWN_FACES_DIR):
        print("[ERROR] known_faces/ folder not found. Create it and add student photos.")
        return

    # Collect all valid image files
    image_files = [
        f for f in os.listdir(KNOWN_FACES_DIR)
        if os.path.splitext(f)[1].lower() in VALID_EXTENSIONS
    ]

    if not image_files:
        print("[ERROR] No images found in known_faces/. Add student photos and re-run.")
        return

    print(f"[INFO] Found {len(image_files)} image(s). Starting encoding...\n")

    known_encodings = []
    known_names     = []

    # Track results for summary
    success_list    = []
    skipped_list    = []
    seen_names      = {}   # for duplicate name detection

    for filename in image_files:
        student_name = os.path.splitext(filename)[0].strip()
        image_path   = os.path.join(KNOWN_FACES_DIR, filename)

        print(f"  Processing: {filename}")

        # ── GUARD: Corrupted or unreadable image ─────────────────────────
        try:
            pil_image = Image.open(image_path).convert("RGB")
        except (UnidentifiedImageError, Exception) as e:
            print(f"    [SKIP] Cannot open image — {e}")
            skipped_list.append((filename, "Corrupted or unreadable file"))
            continue

        # Convert to numpy array for face_recognition
        image = np.ascontiguousarray(np.array(pil_image))

        # ── GUARD: Detect face locations ──────────────────────────────────
        face_locations = face_recognition.face_locations(image)

        if len(face_locations) == 0:
            print(f"    [SKIP] No face detected. Check lighting or photo quality.")
            skipped_list.append((filename, "No face detected"))
            continue

        if len(face_locations) > 1:
            print(f"    [WARNING] Multiple faces found — using the largest face only.")
            # Pick the largest face by bounding box area instead of blindly using index 0
            face_locations = [
                max(
                    face_locations,
                    key=lambda loc: (loc[2] - loc[0]) * (loc[1] - loc[3])
                )
            ]

        top, right, bottom, left = face_locations[0]
        face_height = bottom - top
        face_width  = right - left

        # ── GUARD: Face too small — encoding will be unreliable ───────────
        if face_height < MIN_FACE_HEIGHT or face_width < MIN_FACE_WIDTH:
            print(f"    [SKIP] Face too small ({face_width}x{face_height}px). Use a closer photo.")
            skipped_list.append((filename, f"Face too small ({face_width}x{face_height}px)"))
            continue

        # Generate 128-dimension encoding
        encoding = face_recognition.face_encodings(image, face_locations)[0]

        # ── GUARD: Encoding quality check ─────────────────────────────────
        if not is_valid_encoding(encoding):
            print(f"    [SKIP] Encoding generated is invalid. Try a different photo.")
            skipped_list.append((filename, "Invalid encoding vector"))
            continue

        # ── GUARD: Duplicate student name warning ─────────────────────────
        if student_name in seen_names:
            print(f"    [WARNING] Duplicate name '{student_name}' — both encodings will be stored.")
            print(f"             Previous: {seen_names[student_name]} | Current: {filename}")
        seen_names[student_name] = filename

        # All checks passed — store encoding
        known_encodings.append(encoding)
        known_names.append(student_name)
        success_list.append(filename)
        print(f"    [OK] Encoded successfully — Name: '{student_name}'")

    print()

    # ── Save to pickle ────────────────────────────────────────────────────
    if not known_encodings:
        print("[ERROR] No faces were successfully encoded. Fix the issues above and re-run.")
        return

    data = {"encodings": known_encodings, "names": known_names}

    with open(ENCODINGS_FILE, "wb") as f:
        pickle.dump(data, f)

    # ── Final Summary ─────────────────────────────────────────────────────
    print("=" * 55)
    print("  ENCODING SUMMARY")
    print("=" * 55)
    print(f"  Total images found   : {len(image_files)}")
    print(f"  Successfully encoded : {len(success_list)}")
    print(f"  Skipped              : {len(skipped_list)}")

    if skipped_list:
        print("\n  Skipped Files:")
        for fname, reason in skipped_list:
            print(f"    - {fname}  →  {reason}")

    print(f"\n  Encodings saved to   : {ENCODINGS_FILE}")
    print("=" * 55)


if __name__ == "__main__":
    encode_faces()